# NATIG ARCHIVE

A responsive, dark editorial portfolio website in Azerbaijani, Turkish, English and Russian.

## Publish with GitHub Pages
1. Extract this ZIP on your computer.
2. Open your GitHub repository.
3. Choose **Add file → Upload files**.
4. Upload `index.html` (and this `README.md` if you like), then commit.
5. In the repository, open **Settings → Pages**.
6. Under **Build and deployment**, choose **Deploy from a branch**.
7. Select **main** and **/(root)**, then Save.
8. Wait for GitHub Pages to publish your site.

Replace placeholder project descriptions and add approved contact details before public launch. This is a static site; it has no payment system or content-management dashboard yet.
